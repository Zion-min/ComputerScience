set transaction name 'comp322_2019112635_sionmin';

create table book (
    bookid number primary key not null, 
    bookname varchar(100),
    publisher varchar(20),
    price number
);

savepoint create_table;

insert into book values (1, 'Database', 'Pearson', 30000);

select bookname "bookname1"
  from book
  where bookid = 1;

savepoint insert_1;

update book
  set bookname = 'Intro. to Database'
  where bookid = 1;



select bookname "bookname2"
  from book
  where bookid = 1;

savepoint update_1;

update book set bookname = 'Database Lab.'
  where bookid = 1;

select bookname "bookname3"
  from book
  where bookid = 1;

rollback to update_1;




select bookname "bookname4"
  from book
  where bookid = 1;

rollback to insert_1;

select bookname "bookname5"
  from book
  where bookid = 1;

commit;


update book set bookname = 'Database Lab2' where bookid = 1;

select bookname "bookname6"
  from book
  where bookid = 1;

rollback;


select bookname "bookname7"
  from book
  where bookid = 1;



delete from book where bookid = 1;



select bookname "bookname8"
  from book
  where bookid = 1;




rollback;



select bookname "bookname9"
  from book
  where bookid = 1;

commit;
